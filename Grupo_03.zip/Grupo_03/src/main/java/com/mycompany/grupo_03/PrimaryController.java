package com.mycompany.grupo_03;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.RadioButton;

public class PrimaryController {

    @FXML
    private RadioButton radioX;

    @FXML
    private RadioButton radioHumano;

    @FXML
    private void iniciarPartida() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            App.class.getResource("juego.fxml")
                    );

            Parent root = loader.load();

            JuegoController controller =
                    loader.getController();

            char simboloHumano =
                    radioX.isSelected() ? 'X' : 'O';

            char simboloComputadora =
                    simboloHumano == 'X' ? 'O' : 'X';

            boolean iniciaHumano =
                    radioHumano.isSelected();

            Partida partida =
                    new Partida(
                            simboloHumano,
                            simboloComputadora,
                            iniciaHumano
                    );

            controller.iniciarPartida(partida);

            Stage stage =
                    (Stage) radioX
                            .getScene()
                            .getWindow();

            /*
             * Creamos la nueva escena.
             */
            Scene scene = new Scene(root);

            stage.setScene(scene);

            /*
             * IMPORTANTE:
             * Quitamos cualquier tamaño anterior.
             */
            stage.setMaximized(false);

            /*
             * Obtenemos el tamaño de la pantalla.
             */
            javafx.geometry.Rectangle2D pantalla =
                    javafx.stage.Screen
                            .getPrimary()
                            .getVisualBounds();

            /*
             * Ajustamos la ventana al tamaño
             * disponible de la pantalla.
             */
            stage.setX(pantalla.getMinX());
            stage.setY(pantalla.getMinY());

            stage.setWidth(pantalla.getWidth());
            stage.setHeight(pantalla.getHeight());

            /*
             * Finalmente mostramos la ventana.
             */
            stage.show();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

}