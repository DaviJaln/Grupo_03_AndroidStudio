package com.mycompany.grupo_03;

public class Partida {
    
    private Tablero tablero; //tablero real de la partida 
    private final MiniMax minimax;  //La partida tendrá un Minimax cuando llegue el turno de la compu
    //Las siguientes cosas que creamos es debido a 
    //que se pueds ver con que jugar, ya sea X O o O X
    private final char simboloHumano; 
    private final char simboloComputadora;
    
    private final boolean iniciaHumano;
    
    // Variable para representar a quien le toca jugar
    private char turnoActual;
    
    public Partida(char simboloHumano, char simboloComputadora, boolean iniciaHumano){

        this.tablero = new Tablero();
        this.minimax = new MiniMax();

        this.simboloHumano = simboloHumano;
        this.simboloComputadora = simboloComputadora;

        this.iniciaHumano = iniciaHumano;

        if(iniciaHumano){
            this.turnoActual = simboloHumano;
        }else{
            this.turnoActual = simboloComputadora;
        }
    }
    
    public Tablero getTablero(){
        return tablero;
    }
    public char getTurnoActual(){
        return turnoActual;
    }
    public char getSimboloHumano() {
        return simboloHumano;
    }
    public char getSimboloComputadora() {
        return simboloComputadora;
    }
    public boolean iniciaHumano() {
        return iniciaHumano;
    }
    
    public Tree<Tablero> getArbolMinimax() {
        return minimax.getUltimoArbol();
    }
    
    public int[] getMejorMovimientoMinimax() {
        return minimax.getUltimoMejorMovimiento();
    }
    
    public boolean jugarHumano(int fila, int columna){
        
        //solo continuar si no es el turno del humano
        if(turnoActual != simboloHumano){
            return false;
        }
        
        //validamos si la partida ya acabo
        if(tablero.isFull()||tablero.isWinner(simboloHumano)||tablero.isWinner(simboloComputadora)){
            return false;
        }
        //Intentamos colocar el simbolo del humano
        
        if(!tablero.colocarSimbolo(fila, columna, simboloHumano)){
            return false;
        }
        //SI la partida sigue, pasa el turno a la computadora
        
        if(!tablero.isFull()&& !tablero.isWinner(simboloHumano)){
            turnoActual = simboloComputadora;
        }
        return true;
    }
    public boolean jugarComputadora(){
        
        //SI no le toca al simbolo que le toco a la computadora, no jugamos
        if(turnoActual!= simboloComputadora){
            return false;
        }
        
        //No podemos seguir jugando si ya se acabo el juego por empate o victoria de uno de los dos
        if(tablero.isFull()||tablero.isWinner(simboloHumano)||tablero.isWinner(simboloComputadora)){
            return false;
        }
        
        //Minimax busca la mejor posicion para la computadora
        int[] movimiento = minimax.obtenerMejorMovimiento(tablero, simboloComputadora, simboloHumano);
        
        //Si no hay mov disponible, no hacemos nd pues
        if(movimiento ==null){
            return false;
        }
        
        //colocamos el simbolo de la computadora.
        tablero.colocarSimbolo(movimiento[0],movimiento[1],simboloComputadora);
        
        //si la partida continua, regresamos al humano
        if(!tablero.isFull()&& !tablero.isWinner(simboloComputadora)){
            turnoActual = simboloHumano;
        }
        return true; 
       
    
        
    }
    
    public boolean partidaTerminada(){
        return tablero.isFull()||tablero.isWinner(simboloHumano)||tablero.isWinner(simboloComputadora);
        
    }
    public char obtenerGanador(){
        
        if(tablero.isWinner(simboloHumano)){
            return simboloHumano;
        }
        if(tablero.isWinner(simboloComputadora)){
            return simboloComputadora;
        }
        return Tablero.vacio;
    }
    public boolean esEmpate(){
        return tablero.isFull()&&!tablero.isWinner(simboloHumano)&&!tablero.isWinner(simboloComputadora);
    }
    
     
}

