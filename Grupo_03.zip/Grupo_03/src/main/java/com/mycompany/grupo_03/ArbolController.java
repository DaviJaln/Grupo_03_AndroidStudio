package com.mycompany.grupo_03;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import java.util.List;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class ArbolController {

    @FXML
    private Pane lienzoArbol;
    
    private Tree<Tablero> arbol;

    private char simboloComputadora;
    
    private Partida partidaActual;
    
    private int[] mejorMovimiento;

    private static final double ANCHO_NODO = 135;

    private static final double ALTO_NODO = 150;

    private static final double ESPACIO_HORIZONTAL = 35;

    private static final double ESPACIO_VERTICAL = 100;


    /**
     * Recibe el árbol generado por MiniMax.
     */
    public void mostrarArbol(
            Tree<Tablero> arbol,
            char simboloComputadora,
            int[] mejorMovimiento,
            Partida partidaActual) {

        this.arbol = arbol;
        this.simboloComputadora = simboloComputadora;
        this.partidaActual = partidaActual;

        this.mejorMovimiento =
                mejorMovimiento;

        lienzoArbol.getChildren().clear();

        if (arbol == null || arbol.isEmpty()) {

            Label mensaje = new Label(
                    "No existe un árbol disponible."
            );

            mensaje.setStyle(
                    "-fx-font-size: 20px;" +
                    "-fx-font-weight: bold;"
            );

            lienzoArbol.getChildren().add(mensaje);

            return;
        }

        /*
         * Dibujamos el árbol.
         */
        dibujarArbol();
    }


    /**
     * Construye visualmente el árbol.
     */
private void dibujarArbol() {

    /*
    Label titulo = new Label(
            "ÁRBOL DE DECISIÓN MINIMAX"
    );

    titulo.setStyle(
            "-fx-font-size: 26px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #1F2937;"
    );

    titulo.setLayoutX(
        (anchoLienzo - 300) / 2
    );
    titulo.setLayoutY(20);

    lienzoArbol.getChildren().add(titulo);
    */

    /*
     * Árbol raíz.
     */
    Tree<Tablero> raiz = arbol;


    /*
     * Calculamos cuánto espacio necesita
     * realmente el árbol.
     */
    double anchoSubarbol =
            calcularAnchoSubarbol(raiz);


    /*
     * Dejamos márgenes a ambos lados.
     */
    double margenHorizontal = 100;

    double anchoLienzo =
            anchoSubarbol +
            margenHorizontal * 2;
    
    /*
    Label titulo = new Label(
            "ÁRBOL DE DECISIÓN MINIMAX"
    );

    titulo.setStyle(
            "-fx-font-size: 26px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #1F2937;"
    );

    titulo.setLayoutX(
        (anchoLienzo - 300) / 2
    );

    titulo.setLayoutY(20);

    lienzoArbol.getChildren().add(titulo);
    */

    /*
     * Evitamos que el lienzo sea demasiado pequeño.
     */
    if (anchoLienzo < 1200) {

        anchoLienzo = 1200;
    }


    /*
     * Altura suficiente para varios niveles.
     */
    int niveles =
        calcularAlturaArbol(raiz);

    double altoLienzo =
        150 +
        niveles *
        (ALTO_NODO + ESPACIO_VERTICAL);


    lienzoArbol.setPrefWidth(
            anchoLienzo
    );

    lienzoArbol.setMinWidth(
            anchoLienzo
    );

    lienzoArbol.setPrefHeight(
            altoLienzo
    );

    lienzoArbol.setMinHeight(
            altoLienzo
    );


    /*
     * IMPORTANTE:
     * El árbol comienza siempre dentro
     * del área visible.
     */
    double xInicial =
            (anchoLienzo - ANCHO_NODO) / 2;


    double yInicial = 80;


    dibujarNodo(
            raiz,
            0,
            xInicial,
            yInicial
    );
}


    /**
     * Calcula cuánto espacio necesita
     * cada subárbol.
     */
    private double calcularAnchoSubarbol(
            Tree<Tablero> nodo) {

        if (nodo == null ||
                nodo.isEmpty()) {

            return ANCHO_NODO;
        }

        List<Tree<Tablero>> hijos =
                nodo.getRoot().getChildren();

        if (hijos.isEmpty()) {

            return ANCHO_NODO;
        }

        double anchoHijos = 0;

        for (Tree<Tablero> hijo : hijos) {

            anchoHijos +=
                    calcularAnchoSubarbol(hijo);

            anchoHijos +=
                    ESPACIO_HORIZONTAL;
        }

        anchoHijos -=
                ESPACIO_HORIZONTAL;

        return Math.max(
                ANCHO_NODO,
                anchoHijos
        );
    }


    /**
     * Dibuja un nodo y todos sus hijos.
     */
private void dibujarNodo(
        Tree<Tablero> nodo,
        int nivel,
        double x,
        double y) {

    if (nodo == null || nodo.isEmpty()) {
        return;
    }

    Tablero tablero =
            nodo.getRoot().getContent();

    /*
     * Determinamos si este nodo corresponde
     * a la mejor jugada de la computadora.
     *
     * Solo los hijos directos de la raíz
     * representan las posibles jugadas iniciales.
     */
    boolean esMejorJugada = false;

    if (nivel == 1 && mejorMovimiento != null) {

        int[] movimiento =
                obtenerMovimiento(
                        arbol.getRoot().getContent(),
                        tablero
                );

        if (movimiento != null
                && movimiento[0] == mejorMovimiento[0]
                && movimiento[1] == mejorMovimiento[1]) {

            esMejorJugada = true;
        }
    }

    /*
     * Creamos la representación visual.
     */
    VBox nodoVisual =
            crearNodoVisual(
                    tablero,
                    nivel,
                    esMejorJugada
            );

    nodoVisual.setLayoutX(x);
    nodoVisual.setLayoutY(y);

    /*
     * Agregamos el nodo.
     */
    lienzoArbol.getChildren()
            .add(nodoVisual);

    /*
     * Obtenemos los hijos.
     */
    List<Tree<Tablero>> hijos =
            nodo.getRoot().getChildren();

    if (hijos.isEmpty()) {
        return;
    }

    /*
     * Calculamos el ancho total
     * que necesitan los hijos.
     */
    double anchoTotal = 0;

    for (Tree<Tablero> hijo : hijos) {

        anchoTotal +=
                calcularAnchoSubarbol(hijo);

        anchoTotal +=
                ESPACIO_HORIZONTAL;
    }

    anchoTotal -=
            ESPACIO_HORIZONTAL;

    /*
     * Posición inicial de los hijos.
     */
    double xHijo =
            x +
            (ANCHO_NODO / 2) -
            (anchoTotal / 2);

    if (xHijo < 50) {
        xHijo = 50;
    }

    double yHijo =
            y +
            ALTO_NODO +
            ESPACIO_VERTICAL;

    /*
     * Dibujamos cada hijo.
     */
    for (Tree<Tablero> hijo : hijos) {

        double anchoHijo =
                calcularAnchoSubarbol(hijo);

        double posicionHijo =
                xHijo +
                (anchoHijo / 2) -
                (ANCHO_NODO / 2);

        /*
         * Dibujamos la línea primero.
         */
        Line linea =
                new Line();

        linea.setStartX(
                x + ANCHO_NODO / 2
        );

        linea.setStartY(
                y + ALTO_NODO
        );

        linea.setEndX(
                posicionHijo +
                ANCHO_NODO / 2
        );

        linea.setEndY(
                yHijo
        );

        linea.setStyle(
                "-fx-stroke: #64748B;" +
                "-fx-stroke-width: 2;"
        );

        /*
         * Las líneas quedan detrás
         * de los nodos.
         */
        lienzoArbol.getChildren()
                .add(0, linea);

        /*
         * Dibujamos recursivamente el hijo.
         */
        dibujarNodo(
                hijo,
                nivel + 1,
                posicionHijo,
                yHijo
        );

        xHijo +=
                anchoHijo +
                ESPACIO_HORIZONTAL;
    }
}

private int[] obtenerMovimiento(
        Tablero original,
        Tablero estado) {

    for (int fila = 0;
            fila < Tablero.tamanio;
            fila++) {

        for (int columna = 0;
                columna < Tablero.tamanio;
                columna++) {

            if (original.obtenerCasilla(fila, columna)
                    != estado.obtenerCasilla(fila, columna)) {

                return new int[]{
                    fila,
                    columna
                };
            }
        }
    }

    return null;
}


    /**
     * Crea visualmente un estado del tablero.
     */
private VBox crearNodoVisual(
        Tablero tablero,
        int nivel,
        boolean esMejorJugada) {

    VBox nodo = new VBox(3);

    nodo.setAlignment(Pos.CENTER);

    nodo.setPrefWidth(ANCHO_NODO);
    nodo.setPrefHeight(ALTO_NODO);

    /*
     * ==========================================
     * DETERMINAMOS EL TIPO DE NODO
     * ==========================================
     */

    boolean esComputadora = false;
    boolean esHumano = false;

    /*
     * Nivel 0 = estado actual.
     *
     * Nivel impar:
     *   Computadora
     *
     * Nivel par:
     *   Humano
     *
     * Ejemplo:
     *
     * Nivel 0 -> Estado actual
     * Nivel 1 -> Computadora
     * Nivel 2 -> Humano
     * Nivel 3 -> Computadora
     */

    if (nivel > 0) {

        if (nivel % 2 == 1) {
            esComputadora = true;
        } else {
            esHumano = true;
        }
    }

    /*
     * ==========================================
     * ESTILO DEL NODO
     * ==========================================
     */

    String estiloBase;

    if (esComputadora) {

        estiloBase =
                "-fx-background-color: #ECFDF5;" +
                "-fx-border-color: #16A34A;" +
                "-fx-border-width: 2;" +
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-padding: 6;";

    } else if (esHumano) {

        estiloBase =
                "-fx-background-color: #FFF7ED;" +
                "-fx-border-color: #F97316;" +
                "-fx-border-width: 2;" +
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-padding: 6;";

    } else {

        estiloBase =
                "-fx-background-color: white;" +
                "-fx-border-color: #64748B;" +
                "-fx-border-width: 3;" +
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-padding: 6;";
    }

    nodo.setStyle(estiloBase);

    /*
     * ==========================================
     * MEJOR JUGADA
     * ==========================================
     */

    if (esMejorJugada) {

        nodo.setStyle(
                "-fx-background-color: #DCFCE7;" +
                "-fx-border-color: #15803D;" +
                "-fx-border-width: 4;" +
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-padding: 6;"
        );

        Label mejorJugada =
                new Label("★ MEJOR JUGADA");

        mejorJugada.setStyle(
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #15803D;"
        );

        nodo.getChildren().add(
                mejorJugada
        );
    }

    /*
     * ==========================================
     * NIVEL
     * ==========================================
     */

    Label nivelLabel =
            new Label("Nivel " + nivel);

    nivelLabel.setStyle(
            "-fx-font-size: 10px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #64748B;"
    );

    nodo.getChildren().add(
            nivelLabel
    );

    /*
     * ==========================================
     * TIPO DE JUGADOR
     * ==========================================
     */

    if (esComputadora) {

        Label jugadorLabel =
                new Label("🤖 MAX - Computadora");

        jugadorLabel.setStyle(
                "-fx-font-size: 10px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #15803D;"
        );

        nodo.getChildren().add(
                jugadorLabel
        );

    } else if (esHumano) {

        Label jugadorLabel =
                new Label("👤 MIN - Humano");

        jugadorLabel.setStyle(
                "-fx-font-size: 10px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #C2410C;"
        );

        nodo.getChildren().add(
                jugadorLabel
        );

    } else {

        Label estadoLabel =
                new Label("Estado actual");

        estadoLabel.setStyle(
                "-fx-font-size: 10px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #475569;"
        );

        nodo.getChildren().add(
                estadoLabel
        );
    }

    /*
     * ==========================================
     * TABLERO 3x3
     * ==========================================
     */

    for (int fila = 0;
            fila < Tablero.tamanio;
            fila++) {

        javafx.scene.layout.HBox filaVisual =
                new javafx.scene.layout.HBox(2);

        filaVisual.setAlignment(
                Pos.CENTER
        );

        for (int columna = 0;
                columna < Tablero.tamanio;
                columna++) {

            char simbolo =
                    tablero.obtenerCasilla(
                            fila,
                            columna
                    );

            Label casilla =
                    new Label(
                            simbolo == Tablero.vacio
                                    ? " "
                                    : String.valueOf(simbolo)
                    );
            
            casilla.setAlignment(Pos.CENTER);

            casilla.setPrefSize(28, 28);

            if (simbolo == 'X') {

                casilla.setStyle(
                        "-fx-border-color: #2563EB;" +
                        "-fx-background-color: #EFF6FF;" +
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #2563EB;"
                );

            } else if (simbolo == 'O') {

                casilla.setStyle(
                        "-fx-border-color: #DC2626;" +
                        "-fx-background-color: #FEF2F2;" +
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #DC2626;"
                );

            } else {

                casilla.setStyle(
                        "-fx-border-color: #CBD5E1;" +
                        "-fx-background-color: #F8FAFC;" +
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #64748B;"
                );
            }

            filaVisual.getChildren()
                    .add(casilla);
        }

        nodo.getChildren()
                .add(filaVisual);
    }

    /*
     * ==========================================
     * UTILIDAD
     * ==========================================
     */

    int utilidad =
            tablero.calculateUtility(
                    simboloComputadora
            );

    Label utilidadLabel =
            new Label(
                    "Utilidad: " + utilidad
            );

    utilidadLabel.setStyle(
            "-fx-font-size: 10px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #2563EB;"
    );

    nodo.getChildren()
            .add(utilidadLabel);

    /*
     * ==========================================
     * MOVIMIENTO
     * ==========================================
     */

    if (nivel > 0) {

        int[] movimiento =
                obtenerMovimiento(
                        arbol.getRoot().getContent(),
                        tablero
                );

        if (movimiento != null) {

            Label movimientoLabel =
                    new Label(
                            "Movimiento: (" +
                            movimiento[0] +
                            "," +
                            movimiento[1] +
                            ")"
                    );

            movimientoLabel.setStyle(
                    "-fx-font-size: 10px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #7C3AED;"
            );

            nodo.getChildren()
                    .add(movimientoLabel);
        }
    }

    return nodo;
}

    
    private int calcularAlturaArbol(Tree<Tablero> nodo) {

        if (nodo == null ||
                nodo.isEmpty()) {

            return 0;
        }

        int mayor = 0;

        for (Tree<Tablero> hijo
                : nodo.getRoot().getChildren()) {

            int altura =
                    calcularAlturaArbol(hijo);

            if (altura > mayor) {
                mayor = altura;
            }
        }

        return mayor + 1;
    }
    
    private String tableroComoTexto(Tablero tablero) {

        StringBuilder texto = new StringBuilder();

        for (int fila = 0; fila < Tablero.tamanio; fila++) {

            for (int columna = 0;
                 columna < Tablero.tamanio;
                 columna++) {

                char simbolo =
                        tablero.obtenerCasilla(fila, columna);

                if (simbolo == Tablero.vacio) {
                    texto.append(" ");
                } else {
                    texto.append(simbolo);
                }

                if (columna < Tablero.tamanio - 1) {
                    texto.append("│");
                }
            }

            if (fila < Tablero.tamanio - 1) {
                texto.append("\n─┼─┼─\n");
            }
        }

        return texto.toString();
    }


    /**
     * Cierra la ventana del árbol.
     */
    @FXML
    private void volverAlJuego() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            App.class.getResource("juego.fxml")
                    );

            Parent root = loader.load();

            JuegoController controller =
                    loader.getController();

            /*
             * Recuperamos la misma partida.
             */
            controller.iniciarPartida(
                    partidaActual
            );

            /*
             * Obtenemos la ventana actual.
             */
            Stage stage =
                    (Stage) lienzoArbol
                            .getScene()
                            .getWindow();

            /*
             * Cambiamos nuevamente al juego.
             */
            Scene scene =
                    new Scene(root);

            stage.setScene(scene);

            /*
             * Conservamos la ventana maximizada.
             */
            stage.setMaximized(true);

            stage.show();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    
}
