package com.mycompany.grupo_03;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {

        FXMLLoader fxmlLoader =
                new FXMLLoader(
                        App.class.getResource("primary.fxml")
                );

        Scene scene =
                new Scene(fxmlLoader.load());

        stage.setTitle("Tres en Raya");

        stage.setScene(scene);

        stage.show();

        javafx.geometry.Rectangle2D pantalla =
                javafx.stage.Screen
                        .getPrimary()
                        .getVisualBounds();

        stage.setX(pantalla.getMinX());
        stage.setY(pantalla.getMinY());
        stage.setWidth(pantalla.getWidth());
        stage.setHeight(pantalla.getHeight());
    }

    public static void main(String[] args) {
        launch();
    }

}