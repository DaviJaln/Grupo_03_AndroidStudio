package com.mycompany.grupo_03;

import java.util.ArrayList;

public class MiniMax {
    
    private Tree<Tablero> ultimoArbol;
    
    private int[] ultimoMejorMovimiento;
    
    public Tree<Tablero> getUltimoArbol() {
        return ultimoArbol;
    }
    
    public int[] getUltimoMejorMovimiento() {
        return ultimoMejorMovimiento;
    }
    
    /*
     * Obtiene el mejor movimiento para la computadora.
     *
     * La diferencia principal con la versión anterior es que
     * ahora MiniMax recorre recursivamente TODO el árbol de estados.
     */
    public int[] obtenerMejorMovimiento(
            Tablero tableroActual,
            char simboloComputadora,
            char simboloOponente) {

        // Si la partida ya terminó, no hay movimiento.
        if (tableroActual.isFull()
                || tableroActual.isWinner(simboloComputadora)
                || tableroActual.isWinner(simboloOponente)) {

            return null;
        }
        
        ultimoMejorMovimiento = null;

        /*
         * Creamos el árbol cuya raíz representa
         * el estado actual del tablero.
         */
        ultimoArbol =
                new Tree<>(tableroActual);

        Tree<Tablero> arbolEstados =
                ultimoArbol;

        /*
         * Generamos todos los movimientos posibles
         * de la computadora.
         */
        ArrayList<Tablero> estados =
                tableroActual.generateStates(simboloComputadora);

        /*
         * Construimos recursivamente todo el árbol.
         */
        for (Tablero estado : estados) {

            Tree<Tablero> hijo =
                    new Tree<>(estado);

            arbolEstados.getRoot().addChild(hijo);

            construirArbol(
                    hijo,
                    simboloOponente,
                    simboloComputadora,
                    simboloOponente
            );
        }

        /*
         * Buscamos cuál de los hijos tiene
         * la mejor evaluación para la computadora.
         */
        int mejorValor = Integer.MIN_VALUE;

        ArrayList<Tree<Tablero>> mejoresJugadas =
                new ArrayList<>();

        for (Tree<Tablero> hijo
                : arbolEstados.getRoot().getChildren()) {

            int valor = minimax(
                    hijo,
                    false,
                    simboloComputadora,
                    simboloOponente,
                    1
            );

            if (valor > mejorValor) {

                mejorValor = valor;

                mejoresJugadas.clear();

                mejoresJugadas.add(hijo);

            } else if (valor == mejorValor) {

                mejoresJugadas.add(hijo);
            }
        }

        /*
         * Si existen varias jugadas con la misma puntuación,
         * utilizamos nuestra prioridad:
         *
         * Centro > Esquina > Borde
         */
        int mejorPrioridad = Integer.MIN_VALUE;

        int[] movimientoElegido = null;

        for (Tree<Tablero> jugada : mejoresJugadas) {

            Tablero estadoJugada =
                    jugada.getRoot().getContent();

            int[] movimiento =
                    obtenerMovimiento(
                            tableroActual,
                            estadoJugada
                    );

            if (movimiento == null) {
                continue;
            }

            int prioridad =
                    prioridadMovimiento(
                            movimiento[0],
                            movimiento[1]
                    );

                if (prioridad > mejorPrioridad) {

                    mejorPrioridad = prioridad;

                    movimientoElegido = movimiento;
                }
        }
        ultimoMejorMovimiento = movimientoElegido;

        return movimientoElegido;
    }

    /*
     * Construye recursivamente el árbol completo.
     *
     * turnoActual indica quién debe jugar en este estado.
     */
    private void construirArbol(
            Tree<Tablero> nodo,
            char turnoActual,
            char simboloComputadora,
            char simboloOponente) {

        Tablero tablero =
                nodo.getRoot().getContent();

        /*
         * Si el estado ya terminó, no generamos hijos.
         */
        if (tablero.isFull()
                || tablero.isWinner(simboloComputadora)
                || tablero.isWinner(simboloOponente)) {

            return;
        }

        /*
         * Generamos todos los movimientos posibles
         * del jugador correspondiente.
         */
        ArrayList<Tablero> estados =
                tablero.generateStates(turnoActual);

        for (Tablero estado : estados) {

            Tree<Tablero> hijo =
                    new Tree<>(estado);

            nodo.getRoot().addChild(hijo);

            /*
             * Alternamos el turno.
             */
            char siguienteTurno;

            if (turnoActual == simboloComputadora) {

                siguienteTurno = simboloOponente;

            } else {

                siguienteTurno = simboloComputadora;
            }

            /*
             * Seguimos construyendo el árbol.
             */
            construirArbol(
                    hijo,
                    siguienteTurno,
                    simboloComputadora,
                    simboloOponente
            );
        }
    }

    /*
     * Algoritmo MiniMax recursivo.
     *
     * maximiza cuando es turno de la computadora.
     * minimiza cuando es turno del oponente.
     */
    private int minimax(
            Tree<Tablero> nodo,
            boolean maximizando,
            char simboloComputadora,
            char simboloOponente,
            int profundidad) {

        Tablero tablero =
                nodo.getRoot().getContent();

        /*
         * Caso terminal:
         * ganó la computadora.
         */
        if (tablero.isWinner(simboloComputadora)) {

            return 10 - profundidad;
        }

        /*
         * Caso terminal:
         * ganó el oponente.
         */
        if (tablero.isWinner(simboloOponente)) {

            return profundidad - 10;
        }

        /*
         * Caso terminal:
         * empate.
         */
        if (tablero.isFull()) {

            return 0;
        }

        /*
         * Turno de la computadora:
         * buscamos el valor MÁXIMO.
         */
        if (maximizando) {

            int mejorValor = Integer.MIN_VALUE;

            for (Tree<Tablero> hijo
                    : nodo.getRoot().getChildren()) {

                int valor =
                        minimax(
                                hijo,
                                false,
                                simboloComputadora,
                                simboloOponente,
                                profundidad + 1
                        );

                mejorValor =
                        Math.max(mejorValor, valor);
            }

            return mejorValor;

        } else {

            /*
             * Turno del oponente:
             * buscamos el valor MÍNIMO.
             */
            int mejorValor = Integer.MAX_VALUE;

            for (Tree<Tablero> hijo
                    : nodo.getRoot().getChildren()) {

                int valor =
                        minimax(
                                hijo,
                                true,
                                simboloComputadora,
                                simboloOponente,
                                profundidad + 1
                        );

                mejorValor =
                        Math.min(mejorValor, valor);
            }

            return mejorValor;
        }
    }

    /*
     * Compara el tablero original con el tablero
     * resultante para encontrar qué casilla cambió.
     */
    private int[] obtenerMovimiento(
            Tablero original,
            Tablero estado) {

        for (int fila = 0;
                fila < Tablero.tamanio;
                fila++) {

            for (int columna = 0;
                    columna < Tablero.tamanio;
                    columna++) {

                if (original.obtenerCasilla(fila, columna)
                        != estado.obtenerCasilla(fila, columna)) {

                    return new int[]{
                        fila,
                        columna
                    };
                }
            }
        }

        return null;
    }

    /*
     * Prioridad de movimientos:
     *
     * Centro  = 3
     * Esquina = 2
     * Borde   = 1
     */
    private int prioridadMovimiento(
            int fila,
            int columna) {

        // Centro
        if (fila == 1 && columna == 1) {

            return 3;
        }

        // Esquinas
        if ((fila == 0 || fila == Tablero.tamanio - 1)
                && (columna == 0
                || columna == Tablero.tamanio - 1)) {

            return 2;
        }

        // Bordes
        return 1;
    }
}
