package com.mycompany.grupo_03;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.stage.Stage;

public class JuegoController {

    private Partida partida;

    @FXML
    private Label labelTurno;

    @FXML
    private Button boton00;

    @FXML
    private Button boton01;

    @FXML
    private Button boton02;

    @FXML
    private Button boton10;

    @FXML
    private Button boton11;

    @FXML
    private Button boton12;

    @FXML
    private Button boton20;

    @FXML
    private Button boton21;

    @FXML
    private Button boton22;
    
    @FXML
    private Button botonNuevaPartida;

    @FXML
    private Button botonVolverInicio;

    public void iniciarPartida(Partida partida) {

        this.partida = partida;

        configurarBotones();

        actualizarTablero();

        // Si empieza la computadora,
        // realiza su primera jugada automáticamente.
        if (partida.getTurnoActual() == obtenerSimboloComputadora()) {
            jugarComputadora();
        }
    }

    private void configurarBotones() {

        boton00.setOnAction(e -> jugar(0, 0));
        boton01.setOnAction(e -> jugar(0, 1));
        boton02.setOnAction(e -> jugar(0, 2));

        boton10.setOnAction(e -> jugar(1, 0));
        boton11.setOnAction(e -> jugar(1, 1));
        boton12.setOnAction(e -> jugar(1, 2));

        boton20.setOnAction(e -> jugar(2, 0));
        boton21.setOnAction(e -> jugar(2, 1));
        boton22.setOnAction(e -> jugar(2, 2));
    }

    private void jugar(int fila, int columna) {

        boolean movimientoValido =
                partida.jugarHumano(fila, columna);

        if (!movimientoValido) {
            return;
        }

        actualizarTablero();

        if (partida.partidaTerminada()) {
            finalizarPartida();
            return;
        }

        jugarComputadora();
    }

    private void jugarComputadora() {

        boolean movimientoValido =
                partida.jugarComputadora();

        if (!movimientoValido) {
            return;
        }

        actualizarTablero();

        if (partida.partidaTerminada()) {
            finalizarPartida();
        }
    }

    private void actualizarTablero() {

        Button[][] botones = obtenerBotones();

        for (int fila = 0; fila < Tablero.tamanio; fila++) {

            for (int columna = 0;
                 columna < Tablero.tamanio;
                 columna++) {

                char simbolo =
                        partida.getTablero()
                               .obtenerCasilla(fila, columna);

                Button boton = botones[fila][columna];

                if (simbolo == Tablero.vacio) {

                    boton.setText("");
                    boton.setDisable(false);

                    aplicarEstiloVacio(boton);

                } else {

                    boton.setText(String.valueOf(simbolo));
                    boton.setDisable(true);

                    if (simbolo == 'X') {
                        aplicarEstiloX(boton);
                    } else {
                        aplicarEstiloO(boton);
                    }
                }
            }
        }

        if (!partida.partidaTerminada()) {

            labelTurno.setText(
                    "Turno: " + partida.getTurnoActual()
            );
        }
    }

    private Button[][] obtenerBotones() {

        return new Button[][]{
            {boton00, boton01, boton02},
            {boton10, boton11, boton12},
            {boton20, boton21, boton22}
        };
    }

    private void aplicarEstiloVacio(Button boton) {

        boton.setStyle(
            "-fx-font-size: 42px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-color: white;" +
            "-fx-border-color: #CBD5E1;" +
            "-fx-border-width: 2;" +
            "-fx-background-radius: 8;" +
            "-fx-border-radius: 8;" +
            "-fx-cursor: hand;"
        );
    }

    private void aplicarEstiloX(Button boton) {

        boton.setStyle(
            "-fx-font-size: 42px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #2563EB;" +
            "-fx-background-color: #EFF6FF;" +
            "-fx-border-color: #2563EB;" +
            "-fx-border-width: 2;" +
            "-fx-background-radius: 8;" +
            "-fx-border-radius: 8;"
        );
    }

    private void aplicarEstiloO(Button boton) {

        boton.setStyle(
            "-fx-font-size: 42px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #DC2626;" +
            "-fx-background-color: #FEF2F2;" +
            "-fx-border-color: #DC2626;" +
            "-fx-border-width: 2;" +
            "-fx-background-radius: 8;" +
            "-fx-border-radius: 8;"
        );
    }

    private void resaltarLineaGanadora() {

        char ganador = partida.obtenerGanador();

        if (ganador == Tablero.vacio) {
            return;
        }

        int[][] linea =
                partida.getTablero()
                       .obtenerLineaGanadora(ganador);

        if (linea == null) {
            return;
        }

        Button[][] botones = obtenerBotones();

        // Resaltamos las tres casillas ganadoras
        for (int[] posicion : linea) {

            int fila = posicion[0];
            int columna = posicion[1];

            Button boton = botones[fila][columna];

            boton.setStyle(
                "-fx-font-size: 42px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: white;" +
                "-fx-background-color: #16A34A;" +
                "-fx-border-color: #15803D;" +
                "-fx-border-width: 4;" +
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;"
            );
        }
    }

    private char obtenerSimboloComputadora() {

        return partida.getSimboloComputadora();
    }

    private void finalizarPartida() {

        // Actualizamos el tablero
        actualizarTablero();

        // Si hubo ganador, resaltamos su línea
        if (!partida.esEmpate()) {
            resaltarLineaGanadora();
        }

        // Deshabilitamos todas las casillas
        deshabilitarTablero();

        mostrarResultado();
    }

    private void deshabilitarTablero() {

        boton00.setDisable(true);
        boton01.setDisable(true);
        boton02.setDisable(true);

        boton10.setDisable(true);
        boton11.setDisable(true);
        boton12.setDisable(true);

        boton20.setDisable(true);
        boton21.setDisable(true);
        boton22.setDisable(true);
    }

    private void mostrarResultado() {

        String mensaje;

        if (partida.esEmpate()) {

            mensaje = "¡EMPATE!";

        } else {

            char ganador = partida.obtenerGanador();

            mensaje = "¡GANÓ " + ganador + "!";
        }

        labelTurno.setText(mensaje);

        Alert alerta =
                new Alert(Alert.AlertType.INFORMATION);

        alerta.setTitle("Fin de la partida");
        alerta.setHeaderText("TRES EN RAYA");
        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
    
    @FXML
    private void nuevaPartida() {

        char simboloHumano = partida.getSimboloHumano();

        char simboloComputadora =
                partida.getSimboloComputadora();

        boolean iniciaHumano =
                partida.iniciaHumano();

        Partida nuevaPartida = new Partida(
                simboloHumano,
                simboloComputadora,
                iniciaHumano
        );

        iniciarPartida(nuevaPartida);
    }
    
    @FXML
    private void volverAlInicio() {

        try {

            FXMLLoader loader =
                    new FXMLLoader(
                            App.class.getResource("primary.fxml")
                    );

            Parent root = loader.load();

            Stage stage =
                    (Stage) botonVolverInicio
                            .getScene()
                            .getWindow();

            Scene scene =
                    new Scene(root);

            stage.setScene(scene);

            /*
             * Obtenemos el tamaño disponible de la pantalla.
             */
            javafx.geometry.Rectangle2D pantalla =
                    javafx.stage.Screen
                            .getPrimary()
                            .getVisualBounds();

            /*
             * Ajustamos nuevamente la ventana
             * al tamaño completo disponible.
             */
            stage.setX(pantalla.getMinX());
            stage.setY(pantalla.getMinY());

            stage.setWidth(pantalla.getWidth());
            stage.setHeight(pantalla.getHeight());

            stage.show();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
    
    @FXML
    private void mostrarArbol() {

        try {

            /*
             * Obtenemos el árbol que MiniMax generó
             * durante su última jugada.
             */
            Tree<Tablero> arbol =
                    partida.getArbolMinimax();

            if (arbol == null) {

                Alert alerta =
                        new Alert(Alert.AlertType.INFORMATION);

                alerta.setTitle("Árbol MiniMax");
                alerta.setHeaderText(null);
                alerta.setContentText(
                        "La computadora todavía no ha realizado una jugada."
                );

                alerta.showAndWait();

                return;
            }

            /*
             * Cargamos la ventana del árbol.
             */
            FXMLLoader loader =
                    new FXMLLoader(
                            App.class.getResource("arbol.fxml")
                    );

            Parent root = loader.load();

            /*
             * Obtenemos el controlador.
             */
            ArbolController controller =
                    loader.getController();

            /*
             * Enviamos el árbol generado por MiniMax.
             */
            controller.mostrarArbol(
                    arbol,
                    partida.getSimboloComputadora(),
                    partida.getMejorMovimientoMinimax(),
                    partida
            );

            /*
             * Utilizamos la misma ventana actual.
             * Así mantenemos el estado maximizado.
             */
            Stage stage =
                    (Stage) botonVolverInicio
                            .getScene()
                            .getWindow();

            Scene scene =
                    new Scene(root);

            stage.setScene(scene);

            /*
             * Mantenemos la ventana maximizada.
             */
            stage.setMaximized(true);

            stage.show();

        } catch (Exception e) {

            e.printStackTrace();

            Alert alerta =
                    new Alert(Alert.AlertType.ERROR);

            alerta.setTitle("Error");

            alerta.setHeaderText(
                    "No se pudo mostrar el árbol"
            );

            alerta.setContentText(
                    e.getMessage()
            );

            alerta.showAndWait();
        }
    }
}



