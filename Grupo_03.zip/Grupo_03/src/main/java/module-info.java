module com.mycompany.grupo_03 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.grupo_03 to javafx.fxml;
    exports com.mycompany.grupo_03;
}
